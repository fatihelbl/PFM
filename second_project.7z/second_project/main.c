#include "mcc_generated_files/mcc.h"

void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    TRISA7 = 0;
    uint8_t counter = 0;
    
    while (1)
    {
        LATA7 = 1;
        __delay_ms(100);
        printf("I'm Here");
        LATA7 = 0;
        __delay_ms(100);
        
        counter++;
        
        
        if(counter == 3)
        {
          asm("goto 0x500");
          counter = 0;
        }
    }
}
