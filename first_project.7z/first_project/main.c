#include "mcc_generated_files/mcc.h"
#include "string.h"
#include "language_support.h"

void main(void)
{
    SYSTEM_Initialize();

    TRISA6 = 0;
    uint8_t counter = 0;
    
    while (1)
    {
      LATA6 = 1;
      __delay_ms(500);
      printf("");
      LATA6 = 0;
      __delay_ms(500);
      
      counter++;
      
      if(counter == 3)
      {
          asm("goto 0x7d0");
          counter = 0;
      }
    }
}